package com.example.myfirstcamera;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import java.io.File;
import java.io.FileOutputStream;


public class MainActivity extends AppCompatActivity {

    Button takePhoto;
    ImageView viewPhoto;
    FloatingActionButton saveImage,cancel;
    Bitmap bp;
    private static final int CAMERA_CAPTURE_CODE= 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        takePhoto = findViewById(R.id.shootPhoto);
        viewPhoto = findViewById(R.id.imageView);
        saveImage = findViewById(R.id.save);
        cancel = findViewById(R.id.cancel);

        takePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(camera,CAMERA_CAPTURE_CODE);
            }
        });

        saveImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean hasImage1 = (viewPhoto.getDrawable() != null);//To check ViewImage got image or not.
                if(hasImage1) {
                    ContextWrapper cw = new ContextWrapper(getApplicationContext());
                    File dir = cw.getDir("imageDir", Context.MODE_PRIVATE);
                    File file = new File(dir, "MyImage" + System.currentTimeMillis() + ".jpg");
                    if (!file.exists()) {
                        Log.d("path", file.toString());
                        FileOutputStream fos;
                        try {
                            fos = new FileOutputStream(file);
                            bp = ((BitmapDrawable) viewPhoto.getDrawable()).getBitmap();
                            //Compress the bitmap with JPEG format and quality 100%
                            bp.compress(Bitmap.CompressFormat.JPEG, 100, fos);
                            fos.flush();
                            fos.close();
                            Snackbar.make(v, "Image saved...", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        } catch (java.io.IOException e) {
                            Snackbar.make(v, "Error saving Image...", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                            e.printStackTrace();
                        }
                    }
                }
                else
                {
                    Snackbar.make(v, "No image to save...", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // viewPhoto.setImageResource(android.R.color.transparent);
                viewPhoto.setImageDrawable(null);
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
       super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_CAPTURE_CODE) {
            if (resultCode == RESULT_OK) {
                    try {
                         bp = (Bitmap) data.getExtras().get("data");
                         viewPhoto.setImageBitmap(bp);
                    }
                    catch(Exception ex)
                     {
                         System.out.println("Error " + ex.getMessage());
                     }
            }
            else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "Cancelled", Toast.LENGTH_LONG).show();
            }

        }
    }
}
